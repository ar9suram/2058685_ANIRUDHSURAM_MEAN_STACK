step 0: npm install 
 
 step 1: npm i --save-dev nodemon

 step 2: to run the program

 npm run start